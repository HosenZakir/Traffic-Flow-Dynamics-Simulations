//Approximately correct code

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <sstream>

using namespace std;

// --- Pattern Selection (Section V) ---
const double beta1 = 0.75;
const double beta2 = 0.25;
const double lam1 = 0.0;
const double lam2 = 0.0;

const double L = 800.0;
const double Time = 15000.0;
const double dt = 0.1;
//const int Tsteps = (int)(Time / dt) + 100;
const int Tsteps = (int)(Time / dt);

// Lane 1 Parameters
const int N1 = 160;
const double a1 = 2.5;
const double tau1 = 1.0 / a1;   // 0.4s (4 steps)
const double v_max1 = 2.5;
const double hc1 = 4.5;     //4.5,5.0

// Lane 2 Parameters
const int N2 = 200;
const double a2 = 2.0;
const double tau2 = 1.0 / a2;   // 0.5s (5 steps)
const double v_max2 = 2.0;
const double hc2 = 4.0;

// Memory structures
vector<vector<double>> dx1(N1, vector<double>(Tsteps, 5.0));
vector<vector<double>> dx2(N2, vector<double>(Tsteps, 4.0));
vector<vector<double>> x1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> x2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> lat1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> lat2(N2, vector<double>(Tsteps, 0.0));

// Optimal Velocity Function
inline double OV(double dx_w, double v_max, double hc)
{
    return 0.5 * v_max * (tanh(dx_w - hc) + tanh(hc));
}

// Lateral distance logic
double getLatDist(double my_pos, const vector<vector<double>>& other_x, int step, int other_N)
{
    double min_dist = L;
    for (int k = 0; k < other_N; k++)
    {
        double dist = other_x[k][step] - my_pos;
        if (dist < 0) dist += L;
        if (dist < min_dist) min_dist = dist;
    }
    return min_dist;
}

void Headway(int i)
{
    // Reconstruct X positions from current headways
    x1[0][i] = 0.0;
    for (int j = 0; j < N1 - 1; j++) x1[j + 1][i] = x1[j][i] + dx1[j][i];

    x2[0][i] = 0.0;
    for (int j = 0; j < N2 - 1; j++) x2[j + 1][i] = x2[j][i] + dx2[j][i];

    // Calculate Lateral distances (coupling)
    for (int j = 0; j < N1; j++) lat1[j][i] = getLatDist(x1[j][i], x2, i, N2);
    for (int j = 0; j < N2; j++) lat2[j][i] = getLatDist(x2[j][i], x1, i, N1);
}

void Model(int i)
{
    Headway(i);

    int s1 = 4; // tau1/dt (reaction time steps for lane 1)
    int s2 = 5; // tau2/dt (reaction time steps for lane 2)

    // --- Lane 1 Update (Discrete Map Eq 18) ---
    if (i % s1 == 0 && i >= s1 && (i + s1) < Tsteps)
    {
        for (int j = 0; j < N1; j++)
        {
            int s1_delay = i - s1; // Time t
            int n_plus = (j + 1) % N1;

            // V terms are evaluated at delay time t
            double w_n = beta1 * dx1[j][s1_delay] + beta2 * lat1[j][s1_delay];
            double w_n_plus = beta1 * dx1[n_plus][s1_delay] + beta2 * lat1[n_plus][s1_delay];
            double V_diff = OV(w_n_plus, v_max1, hc1) - OV(w_n, v_max1, hc1);

            // Trend uses current (t+tau) and delay (t)
            double Trend = (dx1[n_plus][i] - dx1[n_plus][s1_delay]) - (dx1[j][i] - dx1[j][s1_delay]);
            double next_val = dx1[j][i] + tau1 * V_diff + lam1 * tau1 * Trend;

            // Fill future steps until next discrete update to prevent gaps
            for (int k = 1; k <= s1; k++)
            {
                dx1[j][i + k] = next_val;
            }

        }
    }

    // --- Lane 2 Update (Discrete Map Eq 18) ---
    if (i % s2 == 0 && i >= s2 && (i + s2) < Tsteps)
    {
        for (int j = 0; j < N2; j++)
        {
            int s2_delay = i - s2;
            int n_plus = (j + 1) % N2;

            double w_n = beta1 * dx2[j][s2_delay] + beta2 * lat2[j][s2_delay];
            double w_n_plus = beta1 * dx2[n_plus][s2_delay] + beta2 * lat2[n_plus][s2_delay];

            double V_diff = OV(w_n_plus, v_max2, hc2) - OV(w_n, v_max2, hc2);
            double Trend = (dx2[n_plus][i] - dx2[n_plus][s2_delay]) - (dx2[j][i] - dx2[j][s2_delay]);

            double next_val = dx2[j][i] + tau2 * V_diff + lam2 * tau2 * Trend;

            for (int k = 1; k <= s2; k++) dx2[j][i + k] = next_val;
        }
    }
}

void initial()
{
    // Initialize first few steps (0 to 1s) to provide enough history for the map
    for (int i = 0; i < 5; i++)   //100
    {
        for (int j = 0; j < N1; j++)
        {
            dx1[j][i] = 5.0;
            if (j == N1 / 2) dx1[j][i] -= 0.1;
            if (j == N1 / 2 + 1) dx1[j][i] += 0.1;
        }
        for (int j = 0; j < N2; j++)
        {
            dx2[j][i] = 4.0;
            if (j == N2 / 2) dx2[j][i] -= 0.1;
            if (j == N2 / 2 + 1) dx2[j][i] += 0.1;
        }
        Headway(i); // Pre-calculate positions and lateral distances for initial state
    }
}

int main()
{
    initial();

    for (int i = 0; i < Tsteps - 1; i++)
    {
        Model(i);
    }

    ostringstream file1, file2;

    file1 << "Results_lane1" << "_b1=" << beta1 << "_b2=" << beta2 << "_L1=" << lam1 << ".csv";
    file2 << "Results_lane2" << "_b1=" << beta1 << "_b2=" << beta2 << "_L2=" << lam2 << ".csv";

    ofstream Data1(file1.str().c_str());
    ofstream Data2(file2.str().c_str());

    Data1 << "Time,CarID,Position,Headway" << endl;
    Data2 << "Time,CarID,Position,Headway" << endl;

    // Output final state (Figure 3 snapshot at t=10120)
    int snapshot = 101200;

    for (int j = 0; j < N1; j++)
    {
        Data1 << fixed << setprecision(6) << snapshot * dt << "," << j << "," << x1[j][snapshot] << "," << dx1[j][snapshot] << endl;
    }

    for (int j = 0; j < N2; j++)
    {
        Data2 << fixed << setprecision(6) << snapshot * dt << "," << j << "," << x2[j][snapshot] << "," << dx2[j][snapshot] << endl;
    }

    return 0;
}
