//Ordinary Eq 5

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <sstream>

using namespace std;

// --- Pattern Selection (Fig 3c: beta2=0.25, lam=0) ---
const double beta1 = 0.75;
const double beta2 = 0.25;
const double lam1  = 0.0;
const double lam2  = 0.0;

const double L = 800.0;
const double TotalTime = 12000.0;
const double dt = 0.1;
const int Tsteps = (int)(TotalTime / dt);

// Lane 1 Parameters (Fast)
const int N1 = 160;
const double alpha1 = 2.5;         // sensitivity (1/tau)
const double tau1 = 1/alpha1;         // sensitivity (1/tau)
const double kappa1 = lam1/tau1;
const double v_max1 = 2.5;
const double hc1 = 4.5;

// Lane 2 Parameters (Slow)
const int N2 = 200;
const double alpha2 = 2.0;         // sensitivity (1/tau)
const double tau2 = 1/alpha2;         // sensitivity (1/tau)
const double kappa2 = lam2/tau2;
const double v_max2 = 2.0;
const double hc2 = 4.0;

// Memory structures - Sized strictly to each lane
vector<vector<double>> x1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> v1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> dx1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> dv1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> fv1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> lat1(N1, vector<double>(Tsteps, 0.0));

vector<vector<double>> x2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> v2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> dx2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> dv2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> fv2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> lat2(N2, vector<double>(Tsteps, 0.0));


// Optimal Velocity Function (Eq. 7)
inline double OV(double dx_w, double v_max, double hc)
{
    return 0.5 * v_max * (tanh(dx_w - hc) + tanh(hc));
}

// Function to find lateral distance (Delta)
double getLatDist(double my_pos, const vector<vector<double>>& other_lane_x, int otherN, int step)
{
    double min_dist = L;
    for (int k = 0; k < otherN; k++)
    {
        double dist = other_lane_x[k][step] - my_pos;
        if (dist < 0) dist += L; // Periodic boundary distance forward
        if (dist < min_dist) min_dist = dist;
    }
    return min_dist;
}

void Headway(int i)
{
    // 1. Same-lane Headway and Velocity Difference
    for (int j = 0; j < N1; j++)
    {
        int next = (j + 1) % N1;
        dx1[j][i] = x1[next][i] - x1[j][i];
        if (dx1[j][i] < -0.5 * L) dx1[j][i] += L;
        dv1[j][i] = v1[next][i] - v1[j][i];

        lat1[j][i] = getLatDist(x1[j][i], x2, N2, i); // 2. Lateral Headway (Nearest car on adjacent lane)
    }
    for (int j = 0; j < N2; j++)
    {
        int next = (j + 1) % N2;
        dx2[j][i] = x2[next][i] - x2[j][i];
        if (dx2[j][i] < -0.5 * L) dx2[j][i] += L;
        dv2[j][i] = v2[next][i] - v2[j][i];

        lat2[j][i] = getLatDist(x2[j][i], x1, N1, i);
    }
}

void Model(int i)
{
    Headway(i);

    // Calculate Acceleration using Equation (5)
    for (int j = 0; j < N1; j++)
    {
        double weighted_dx = beta1 * dx1[j][i] + beta2 * lat1[j][i];
        fv1[j][i] = alpha1 * (OV(weighted_dx, v_max1, hc1) - v1[j][i]) + kappa1 * dv1[j][i];
    }
    for (int j = 0; j < N2; j++)
    {
        double weighted_dx = beta1 * dx2[j][i] + beta2 * lat2[j][i];
        fv2[j][i] = alpha2 * (OV(weighted_dx, v_max2, hc2) - v2[j][i]) + kappa2 * dv2[j][i];
    }

    // Update Velocity and Position (Euler Integration)
    for (int j = 0; j < N1; j++)
    {
        v1[j][i+1]   = v1[j][i] + fv1[j][i] * dt;
        x1[j][i+1]   = x1[j][i] + v1[j][i] * dt;
        if (x1[j][i+1] >= L) x1[j][i+1] -= L;
    }
    for (int j = 0; j < N2; j++)
    {
        v2[j][i+1]   = v2[j][i] + fv2[j][i] * dt;
        x2[j][i+1]   = x2[j][i] + v2[j][i] * dt;
        if (x2[j][i+1] >= L) x2[j][i+1] -= L;
    }
}

void initial()
{
    double h1 = L / (double)N1;
    double h2 = L / (double)N2;

    for (int j = 0; j < N1; j++)
    {
        x1[j][0] = j * h1;
        v1[j][0] = OV(h1, v_max1, hc1);
    }
    // Perturbation on Lane 1
    x1[N1 / 2][0] -= 0.1;
    x1[N1 / 2 + 1][0] += 0.1;

    for (int j = 0; j < N2; j++)
    {
        x2[j][0] = j * h2;
        v2[j][0] = OV(h2, v_max2, hc2);
    }
    // Perturbation on Lane 2
    x2[N2 / 2][0] -= 0.1;
    x2[N2 / 2 + 1][0] += 0.1;
}

int main()
{
    initial();

    for (int i = 0; i < Tsteps-1; i++)
    {
        Model(i);
    }
    ostringstream file1, file2;

    file1 << "Results_lane1" << "_b1=" << beta1 << "_b2=" << beta2 << "_L1=" << lam1 << ".csv";
    file2 << "Results_lane2" << "_b1=" << beta1 << "_b2=" << beta2 << "_L2=" << lam2 << ".csv";

    ofstream Data1(file1.str().c_str());
    ofstream Data2(file2.str().c_str());

    Data1 << "Time,CarID,Position,Headway" << endl;
    Data2 << "Time,CarID,Position,Headway" << endl;

    // Output final state (Figure 3 snapshot at t=10120)
    int snapshot = 101200;

    for (int j = 0; j < N1; j++)
    {
        Data1 << fixed << setprecision(6) << snapshot * dt << "," << j << "," << x1[j][snapshot] << "," << dx1[j][snapshot] << endl;
    }

    for (int j = 0; j < N2; j++)
    {
        Data2 << fixed << setprecision(6) << snapshot * dt << "," << j << "," << x2[j][snapshot] << "," << dx2[j][snapshot] << endl;
    }

    return 0;
}
