//Good results and approximately correct code

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <random> // Added for distributed noise


using namespace std;

// --- Pattern Selection (Fig 3a: beta1=1, beta2=0, lam=0) ---
const double beta1 = 1.0;
const double beta2 = 0.0;
const double lam1 = 0.3;
const double lam2 = 0.2;

const double L = 800.0;
const double Time = 15000.0;
const double dt = 0.1;
const int Tsteps = (int)(Time / dt);

// Lane 1 Parameters (Section V)
const int N1 = 160;
const double a1 = 2.5;
const double tau1 = 1.0 / a1;   // 0.4s (4 steps)
const double v_max1 = 2.5;
const double hc1 = 5.0;     //4.5

// Lane 2 Parameters (Section V)
const int N2 = 200;
const double a2 = 2.0;
const double tau2 = 1.0 / a2;   // 0.5s (5 steps)
const double v_max2 = 2.0;
const double hc2 = 4.0;

// Memory structures
vector<vector<double>> dx1(N1, vector<double>(Tsteps, 5.0));
vector<vector<double>> dx2(N2, vector<double>(Tsteps, 4.0));
vector<vector<double>> x1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> x2(N2, vector<double>(Tsteps, 0.0));
vector<vector<double>> lat1(N1, vector<double>(Tsteps, 0.0));
vector<vector<double>> lat2(N2, vector<double>(Tsteps, 0.0));

inline double OV(double dx_w, double v_max, double hc)
{
    return 0.5 * v_max * (tanh(dx_w - hc) + tanh(hc));
}

double getLatDist(double my_pos, const vector<vector<double>>& other_x, int step, int other_N)
{
    double min_dist = L;
    for (int k = 0; k < other_N; k++)
    {
        double dist = other_x[k][step] - my_pos;
        if (dist < 0) dist += L;
        if (dist < min_dist) min_dist = dist;
    }
    return min_dist;
}

void Headway(int i)
{
    // Reconstruct X positions
    x1[0][i] = 0.0;
    for (int j = 0; j < N1 - 1; j++)
    {
        x1[j + 1][i] = x1[j][i] + dx1[j][i];
    }

    x2[0][i] = 0.0;
    for (int j = 0; j < N2 - 1; j++)
    {
        x2[j + 1][i] = x2[j][i] + dx2[j][i];
    }

    // Calculate Lateral Distances
    for (int j = 0; j < N1; j++)
    {
        lat1[j][i] = getLatDist(x1[j][i], x2, i, N2);
    }

    for (int j = 0; j < N2; j++)
    {
        lat2[j][i] = getLatDist(x2[j][i], x1, i, N1);
    }


}

/*
void Model(int i) {
    Headway(i);

    int s1 = 4; // tau1/dt
    int s2 = 5; // tau2/dt

    // --- Lane 1 Update (Synchronous) ---
    if (i % s1 == 0 && i >= s1 && (i + s1) < Tsteps) {
        vector<double> next_dx1(N1);
        for (int j = 0; j < N1; j++) {
            int s1_delay = i - s1;
            int n_plus = (j + 1) % N1;

            double w_n_t = beta1 * dx1[j][s1_delay] + beta2 * lat1[j][s1_delay];
            double w_n_plus_t = beta1 * dx1[n_plus][s1_delay] + beta2 * lat1[n_plus][s1_delay];

            double V_term = tau1 * (OV(w_n_plus_t, v_max1, hc1) - OV(w_n_t, v_max1, hc1));
            double Trend = (dx1[n_plus][i] - dx1[n_plus][s1_delay]) - (dx1[j][i] - dx1[j][s1_delay]);

            next_dx1[j] = dx1[j][i] + V_term + lam1 * tau1 * Trend;
        }
        for (int j = 0; j < N1; j++) {
            for (int k = 1; k <= s1; k++) dx1[j][i + k] = next_dx1[j];
        }
    }

    // --- Lane 2 Update (Synchronous) ---
    if (i % s2 == 0 && i >= s2 && (i + s2) < Tsteps) {
        vector<double> next_dx2(N2);
        for (int j = 0; j < N2; j++) {
            int s2_delay = i - s2;
            int n_plus = (j + 1) % N2;

            double w_n_t = beta1 * dx2[j][s2_delay] + beta2 * lat2[j][s2_delay];
            double w_n_plus_t = beta1 * dx2[n_plus][s2_delay] + beta2 * lat2[n_plus][s2_delay];

            double V_term = tau2 * (OV(w_n_plus_t, v_max2, hc2) - OV(w_n_t, v_max2, hc2));
            double Trend = (dx2[n_plus][i] - dx2[n_plus][s2_delay]) - (dx2[j][i] - dx2[j][s2_delay]);

            next_dx2[j] = dx2[j][i] + V_term + lam2 * tau2 * Trend;
        }
        for (int j = 0; j < N2; j++) {
            for (int k = 1; k <= s2; k++) dx2[j][i + k] = next_dx2[j];
        }
    }
}
*/

void Model(int i)
{
    Headway(i);

    int s1 = 4; // tau1/dt
    int s2 = 5; // tau2/dt

    // --- Lane 1 Update (Eq. 18 with stimulus at i-s1) ---
    if (i % s1 == 0 && i >= s1 && (i + s1) < Tsteps)
    {
        vector<double> next_step_dx(N1);

        for (int j = 0; j < N1; j++)
        {
            int n_next = (j + 1) % N1;

            // Stimulus evaluated at time t (i - s1)
            double w_self_t = beta1 * dx1[j][i - s1] + beta2 * lat1[j][i - s1];
            double w_next_t = beta1 * dx1[n_next][i - s1] + beta2 * lat1[n_next][i - s1];

            double V_term = tau1 * (OV(w_next_t, v_max1, hc1) - OV(w_self_t, v_max1, hc1));

            // Lambda term (Trend) uses (t + tau) - (t)
            double Trend = (dx1[n_next][i] - dx1[n_next][i - s1]) - (dx1[j][i] - dx1[j][i - s1]);

            next_step_dx[j] = dx1[j][i] + V_term + lam1 * tau1 * Trend;
        }
        // Apply update to the whole lane synchronously
        for (int j = 0; j < N1; j++)
        {
            for (int k = 1; k <= s1; k++)

            {
                dx1[j][i + k] = next_step_dx[j];
            }
        }
    }

    // --- Lane 2 Update (Eq. 18 with stimulus at i-s2) ---
    if (i % s2 == 0 && i >= s2 && (i + s2) < Tsteps)
    {
        vector<double> next_step_dx(N2);
        for (int j = 0; j < N2; j++)
        {
            int n_next = (j + 1) % N2;

            double w_self_t = beta1 * dx2[j][i - s2] + beta2 * lat2[j][i - s2];
            double w_next_t = beta1 * dx2[n_next][i - s2] + beta2 * lat2[n_next][i - s2];

            double V_term = tau2 * (OV(w_next_t, v_max2, hc2) - OV(w_self_t, v_max2, hc2));
            double Trend = (dx2[n_next][i] - dx2[n_next][i - s2]) - (dx2[j][i] - dx2[j][i - s2]);

            next_step_dx[j] = dx2[j][i] + V_term + lam2 * tau2 * Trend;
        }
        for (int j = 0; j < N2; j++)
        {
            for (int k = 1; k <= s2; k++)
            {
                dx2[j][i + k] = next_step_dx[j];
            }

        }
    }
}
void initial()
{
    mt19937 gen(41);
    uniform_real_distribution<> dis(-0.01, 0.01);

    for (int i = 0; i < Tsteps - 1; i++)
    {
        for(int j=0; j<N1; j++) dx1[j][i] = 5.0 + dis(gen);
        for(int j=0; j<N2; j++) dx2[j][i] = 4.0;

        // Ensure the specific perturbation at N/2 is present
        dx1[N1/2][i] = 5.0 - 0.1;
        dx1[N1/2+1][i] = 5.0 + 0.1;

        dx2[N2/2][i] = 4.0 - 0.1;
        dx2[N2/2+1][i] = 4.0 + 0.1;

        Headway(i);
    }
}
/*

void initial() {
    // Clear vectors to base values
    for(int j=0; j<N1; j++) for(int i=0; i<Tsteps; i++) dx1[j][i] = 5.0;
    for(int j=0; j<N2; j++) for(int i=0; i<Tsteps; i++) dx2[j][i] = 4.0;

    // Apply perturbation specifically for steps t=0 to t=1 (first 10 steps for 1.0s)
    for (int i = 0; i < 10; i++) {
        dx1[N1/2][i] = 5.0 - 0.1;
        dx1[(N1/2)+1][i] = 5.0 + 0.1;

        dx2[N2/2][i] = 4.0 - 0.1;
        dx2[(N2/2)+1][i] = 4.0 + 0.1;
        Headway(i);
    }
}
*/
int main()
{
    initial();
    for (int i = 0; i < Tsteps - 1; i++) Model(i);

    ofstream Data1("Lane1_Final.csv");
    ofstream Data2("Lane2_Final.csv");
    int target = (int)(10120.0 / dt);

    Data1 << "CarNo,Headway" << endl;
    for (int j = 0; j < N1; j++)
    {
        Data1 << j << "," << dx1[j][target] << endl;
    }


    Data2 << "CarNo,Headway" << endl;
    for (int j = 0; j < N2; j++)
    {
        Data2 << j << "," << dx2[j][target] << endl;
    }

    return 0;
}
